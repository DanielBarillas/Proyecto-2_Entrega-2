public class Proyecto{
    private static Vista view = new Vista();
    private static Dietas dietas = new Dietas();
    public static void main(String[] args) {
        Start();
    }

    private static void Start(){
        view.welcomeMessage();
        int opcion =0;
        int selection =1;
        while(opcion != selection){
            opcion = view.meta();
            selection = view.mal(opcion);
            switch(selection){
                case 1:
                    
                    break;
                case 2:
                    dietas.pesoIdeal();
                    break;
                case 3:
                    dietas.IngresoDatos();
                    dietas.fin();
                    break;
                case 4:
                    bajarDePeso();
                    break;
                case 5:
                    subirDePeso();
                    break;
                default:
                    opcion = selection; 
                    view.end_System();
                    System.exit(0);
                    break;
                }
            }
        }

    private static void bajarDePeso(){
        double peso = view.peso();
        double altura = view.altura();
        int opcion = 0;
        int selection = 1;
        while(opcion != selection){
            opcion = view.rutina();
            selection = view.mal(opcion);
            switch(selection){
                case 1:
                    dietas.Dieta1();
                    break;
                case 2: 
                    dietas.ejercicio2();
                    break;
                case 3:
                    Start();
                    break;
        }
    }
}
    private static void subirDePeso(){
        double peso = view.peso();
        double altura = view.altura();
        int opcion = 0;
        int selection =1;
        while(opcion != selection){
            opcion = view.rutina();
            selection = view.mal(opcion);
            switch(selection){
                case 1:
                    dietas.Dieta2();
                    break;
                case 2:
                    dietas.ejercicio1();
                    break;   
                case 3:
                    Start();
                    break;
            }
        }
    }
}
