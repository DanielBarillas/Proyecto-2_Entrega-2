import javax.swing.JOptionPane;

public class Vista {

    public double peso(){

        boolean next_step = false;
        double peso = 0;

        do {

            try {

                peso = Double.parseDouble(JOptionPane.showInputDialog("Cual es su peso (En libras) "));
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }

        } while(!next_step); 

        return peso;

       
    }

    public double altura(){

        boolean next_step = false;
        double altura = 0;

        do {

            try {

                altura = Double.parseDouble(JOptionPane.showInputDialog("Cual es su altura (En centimetros)"));
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }

        } while(!next_step);

        return altura;
    }

    public int meta(){
        System.out.println("------------------------------------------------");
        String[] meta = {"Registrar usuario", "Ver el peso ideal", "Ver IMC", "Bajar de peso" , "Subir de peso", "Salir"};
        for(int i=0; i<meta.length;i++){
            System.out.println((i+1) + ". " + meta[i]);
            System.out.println("------------------------------------------------");
        }return meta.length;
    }

    public int mal(int amountOptions){
        boolean next_step = false;
        int selection = 0;
        do{
            try{
                selection = Integer.parseInt(JOptionPane.showInputDialog("Ingrese una de las opciones: " ));
                if(selection < 0 || selection > amountOptions){
                    System.err.println("\nDEBE INGRESAR UNA OPCION VALIDA\n");
                }else{
                    next_step = true;
                }
            }catch(NumberFormatException e){
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
            }
        }while(!next_step);
        return selection;
    }

    public void welcomeMessage(){
        System.out.println("Bienvenidos a nuestra programa de nutricion, en este programa vas a lograr todas tus metas");
    }

    public int rutina(){
        System.out.println("---------------------------------");
        String[] menuBajarDePeso = {"Ver comidas" , "Ver ejercicios", "Regresar al menu"};
        
        for (int i=0; i<menuBajarDePeso.length;i++){
            System.out.println((i+1) + ". " + menuBajarDePeso[i]);
            System.out.println("---------------------------------");

        }return menuBajarDePeso.length;
    }

    public void end_System(){
        JOptionPane.showMessageDialog(null, "-----Gracias por utilizar nuestro programa, no se rinda hasta lograr todas sus metas-----");
    }


}
