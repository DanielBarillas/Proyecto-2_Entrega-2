public class Usuario {
    String nombres;
    String Apellidos;
    int DPI;
    
    public String getNombres() {
        return nombres;
    }
    public void setNombres(String nombres) {
        this.nombres = nombres;
    }
    public String getApellidos() {
        return Apellidos;
    }
    public void setApellidos(String apellidos) {
        Apellidos = apellidos;
    }
    public int getDPI() {
        return DPI;
    }
    public void setDPI(int dPI) {
        DPI = dPI;
    }

}
