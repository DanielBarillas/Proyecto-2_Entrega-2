import javax.swing.JOptionPane;

public class Dietas {

    private double peso, altura, imc, metros;

    public void Dieta1(){
        JOptionPane.showMessageDialog(null,"Día lunes:\n 7 AM: Tortilla de 2 huevos con espinaca y 1 tomate, Cafe(Solo)\n 10 AM: 1 Manzana y nueces \n 2 PM: Filete de verduras y ensalada \n 5 PM: Taza de frutos rojos y 6 almendras\n 8 PM: Pescado con ensalada de tomate");
        JOptionPane.showMessageDialog(null,"Día martes:\n 7 AM: 2 huevos revueltos con cebolla picada y 1 tomate, Cafe(Solo)\n 10 AM: 1 Pera y 6 almendras\n 2 PM: Pollo a la plancha con pimientos y aguacate\n 5 PM: 1 yogurt y 2 nueces \n 8 PM: Pescado a la plancha con ensalada de espinacas");
        JOptionPane.showMessageDialog(null,"Día miercoles:\n 7 AM: Tortilla de 2 huevos con espinaca y 1 tomate, Cafe(Solo)\n 10 AM: 1 Manzana y nueces\n 2 PM: Pavo con ensalada de lechuga \n 5 PM: Taza de frutos rojos \n 8 PM: Ensalada de atun");
        JOptionPane.showMessageDialog(null,"Día jueves: \n 7 AM: Tortilla de 2 huevos con queso de cabra, Cafe(Solo)\n 10 AM: 1 pera y 6 almendra\n 2 PM: Filete con verduras y ensalada \n 5 PM: 1 yogurt y 2 nueces \n 8 PM: Sopa de calabacion y ensalada");
        JOptionPane.showMessageDialog(null,"Día viernes: \n 7 AM: 2 huevos revueltos, Cafe(Solo) \n 10 AM: 1 manzana y 2 nueces\n 2 PM: Ensalada de atun \n 5 PM: Taza de frutos rojos\n 8 PM: Pescado a la plancha con ensalada de espinaca ");
        JOptionPane.showMessageDialog(null,"Día sabado: \n 7 AM: Tortilla de 2 huevos con espinaca y 1 tomate, Cafe(Solo)\n 10 AM: 1 Manzana y nueces \n 2 PM: Filete de verduras y ensalada \n 5 PM: Taza de frutos rojos y 6 almendras\n 8 PM: Pescado con ensalada de tomate");
        JOptionPane.showMessageDialog(null,"Día domingo: \n 7 AM: 1 yogurt con avena, 3 nueces, 1 fruta, cafe (Solo)\n 10 AM: 1 manzana y 1 trozo de queso \n 2 PM: Salmon al horno con ensalada \n 5 PM: Taza de frutos rojos \n 8 PM: Tortilla de vegetales");
    }

    public void Dieta2(){
        JOptionPane.showMessageDialog(null,"Día lunes:\n 8 AM : 4 repnadas de pan integral con mermelada revuelto de 1 huevo y 4 claras \n 12 PM: 110 gr de pollo, 2 chucaradas de mayonesa y ensalada \n 3 PM: 75 gr de lentejas con carne magra y 1 naranja \n 6 PM: 150 gr de pasta, 110 gr de carne magra y 80 gr de guisantes \n 8 PM: 100 de queso y 2 rojadas de piña ");
        JOptionPane.showMessageDialog(null,"Día martes:\n 8 AM: Batido de proteinas en agua, 80 gr de cereales con 1 vaso de leche y 1 platano \n 12 PM: 1 lata de atun, 1 rebanada de pan integral, 20 gr de frutos secos \n 3 PM: 100 gr de pechuga de pollo, 1 patata cocida grande, 100 gr de brocoli \n 6 PM: 2 trozos pequeños de pizza de queso y ensalada \n 8 PM: 1 rebanada de pan integral, 2 lonchas de queso, 60 gr de carne magra y ensalada de lechuga y tomate");
        JOptionPane.showMessageDialog(null,"Día miercoles: \n 8 AM: Revuleto de 1 huevo y 4 claras, 1 rebanda de pan integral con mermelada, 1 vaso de zumo de naranja \n 12 PM: Medio vaso de queso, 2 cucharadas de miel y macedonia \n 3 PM: Hamburhuesa con pan integral, 1 batido de 125 gr de hidratos \n 6 PM: Batido de proteinas con 500 ml de leche desnatada y 1 platano \n 8 PM: 110 gr de pez espada, 2 patatas medianas y 80 gr de vegetales mezclados");
        JOptionPane.showMessageDialog(null,"Día jueves: \n 8 AM: 80 gr de cereales con leche, 1 vaso de zumo de naranja y 100 gr de queso \n 12 PM:carne picada entre pan integral y ensalada \n 3 PM: 100 gr de raviolis con carne, 100 gr de queso \n 6 PM: 110 gr de salmon, 1 patata grande y 80 gr de maiz \n 8 PM: 1 huevo con 4 claras, 2 lonchas de queso, 1 tostada integral con mermelada y 1 manzana");
        JOptionPane.showMessageDialog(null,"Día viernes: \n 8 AM: Batido de proteinas en agua, 60 gr de cereales con 250 ml de leche y 20 gr de frutos secos \n 12 PM: 40 gr de frutos secos y un batido de proteina \n 3 PM: 175 gr de poollo y de ensalada, 1 patata cocida y 1 vaso de zumo \n 6 PM: 100 gr de muslos de pollo, 150 gr de arroz blanco y 80 gr de guisantes \n 8 PM: batido de proteinas en 500 ml de leche desnatada y 50 gr de fresas");
        JOptionPane.showMessageDialog(null,"Día sabado: \n 8 AM: 2 huevos revueltos, 60 gr de queso, 1 rebanada de pan integral con mermelada y 1 vaso de zumo de naranja \n 12 PM: 2 porciones de piiza de queso \n 3 PM: 100 gr de pechuga de pollo, 1 patata y 50 gr de brocoli \n 6 PM: 100 gr de queso con miel, 1 platano y 1 taza de macedonia \n 8 PM: Hamburguesa de pan integral, 1 vaso de leche desgrasada y 1 bollo dietetico"); 
        JOptionPane.showMessageDialog(null,"Día domingo: Dia libre");
    }

    public void ejercicio1(){
        JOptionPane.showMessageDialog(null,"Día lunes:\n Pecho: \n ---------------------------------------------------------------\n Press banca inclinado(4x12)\n Aperturas inclinadas(3x12) \n Press banca plano (4x12)\n Pullover(3x12)\n --------------------------------------------------------------- \n Hombro:\n --------------------------------------------------------------- \n Press Arnold(3x12) \n Elevaciones frontales (3x12) \n Pajaros (3x12) \n --------------------------------------------------------------- \n Triceps: \n --------------------------------------------------------------- \n Patadas (3x12) \n Extenciones en polea alta (3x12) \n Press Frances (3x12)\n ---------------------------------------------------------------");
        JOptionPane.showMessageDialog(null,"Día martes:\n Espalda \n --------------------------------------------------------------- \n Dominadas(4 al fallo) \n Jalon tras nuca (3x12)\n Jalon al pecho (4x12) \n Remo con barra (3x12) \n --------------------------------------------------------------- \n Biceps: \n --------------------------------------------------------------- \n Curl inclinado con mancuernas (3x12) \n Curl Martillo (3x12) \n Curl concentrado (3x12) \n ---------------------------------------------------------------\n Antebrazo: \n --------------------------------------------------------------- \n Curl supinacion(3x12) \n Curl pronacion(3x12) \n ---------------------------------------------------------------");
        JOptionPane.showMessageDialog(null,"Día miercoles:\n Pierna: \n --------------------------------------------------------------- \n Sentadillas (4x12) \n Peso muerto con barra (4x12) \n Elevacion de talones de pie con barra (3x15)\n --------------------------------------------------------------- \n Trapecio: \n ---------------------------------------------------------------\n Encogemiento con mancuernas (3x12) \n Encogemientos traseros con barra (3x12)\n Encogemientos inclinados con barra (3x12)\n --------------------------------------------------------------- ");
        JOptionPane.showMessageDialog(null,"Día jueves:\n Pecho: \n --------------------------------------------------------------- \n Press banca inclinado(4x12) \n Press banca plano(3x12) \n Aperturas planas(4x12) \n Press banca declinado(3x12) \n --------------------------------------------------------------- \n Hombro: \n --------------------------------------------------------------- \n Press arnold(3x12) \n Elevaciones laterales (3x12) \n Elevaciones frontales (3x12) \n --------------------------------------------------------------- \n Tricpes: \n ---------------------------------------------------------------\n Extenciones en polea alta (3x12) \n Patadas (3x12) \n Fondos entre bancos (3 al fallo) \n --------------------------------------------------------------- ");
        JOptionPane.showMessageDialog(null,"Día viernes:\n  Espalda \n --------------------------------------------------------------- \n Dominadas(4 al fallo) \n Jalon tras nuca (3x12)\n Jalon al pecho (4x12) \n Pullover(3x12) \n --------------------------------------------------------------- \n Biceps: \n --------------------------------------------------------------- \n Curl con barra (3x12) \n Curl Martillo (3x12) \n Curl predicador (3x12) \n ---------------------------------------------------------------\n Antebrazo: \n --------------------------------------------------------------- \n Curl supinacion(3x12) \n Curl pronacion(3x12) \n ---------------------------------------------------------------");
        JOptionPane.showMessageDialog(null,"Día sabado:\n Pierna: \n --------------------------------------------------------------- \n Sentadillas (4x12) \n Peso muerto con barra (4x12) \n Elevacion de talones de pie con barra (3x15)\n --------------------------------------------------------------- \n Trapecio: \n ---------------------------------------------------------------\n Encogemiento con mancuernas (3x12) \n Encogemientos traseros con barra (3x12)\n Encogemientos inclinados con barra (3x12)\n --------------------------------------------------------------- ");
        JOptionPane.showMessageDialog(null,"Día domingo:\n Dia de descanso");
    }

    public void ejercicio2(){
        JOptionPane.showMessageDialog(null,"Día lunes:\n Maquina de step (20 minutos) ");
        JOptionPane.showMessageDialog(null,"Día martes:\n Correr (5 KM) \n Aumentar la distancia cada semana");
        JOptionPane.showMessageDialog(null,"Día miercoles: \n 100 Elevaciones de rodilla \n 40 Mountain climbers  ");
        JOptionPane.showMessageDialog(null,"Día jueves: \n 50 pl.abdome \n 40 lagartijas \n 45 pl.oblicuos");
        JOptionPane.showMessageDialog(null,"Día viernes: \n  Maquina de step (20 minutos) ");
        JOptionPane.showMessageDialog(null,"Día sabado: \n 50 sentadillas \n 50 Elevacion traseras (por cada pierna) \n 50 crunch");
        JOptionPane.showMessageDialog(null,"Día domingo: \n Dia de descanso");
    }

    public void pesoIdeal(){
        String genero = "";
		boolean next_step = false;
		do {
			
			genero = JOptionPane.showInputDialog("Introduce tu género (H (hombre) / M (mujer)): ");
			
		}while(genero.equalsIgnoreCase("H")==false && genero.equalsIgnoreCase("M")==false);
		
        do {
            try {

                int altura = Integer.parseInt(JOptionPane.showInputDialog("Introduce altura (en centimetros)"));
            
                int Peso_Ideal = 0;
                
                if(genero.equalsIgnoreCase("H")) {
                    
                    Peso_Ideal = altura - 110;
                }
                
                else if(genero.equalsIgnoreCase("M")) {
                    
                    Peso_Ideal = altura - 120;
                }
                
                JOptionPane.showMessageDialog(null, "Tu peso  ideal es: "  + Peso_Ideal + " kg");
                
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }
        } while(!next_step); 
	}


    public void IngresoDatos() {
        boolean next_step = false;
        do {
            try {

                peso = Double.parseDouble( JOptionPane.showInputDialog("Ingrese el peso del usuario: "));
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }
        } while(!next_step);

        do {
            try {

                altura = Double.parseDouble( JOptionPane.showInputDialog("Ingrese la altura del usuario: "));
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }
        } while(!next_step);
    }

    public void fin() {
        Double metros = altura/100;
        Double imc = peso/(metros*metros); 
        JOptionPane.showMessageDialog(null, "Debajo de 18, es de peso bajo"+ "\nDe 18 a 25, es de peso Normal"+ "\nDe 25 a 30, es de Sobrepeso"+"\nArriba de 30, es de Obesidad"+"\nSu IMC es de: "+ imc);
    }
   
}


