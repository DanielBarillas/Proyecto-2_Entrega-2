import javax.swing.JOptionPane;

public class Vista {

    public double peso(){
        double peso = Double.parseDouble(JOptionPane.showInputDialog("Cual es su peso (En libras) "));
        return peso;
       
    }

    public double altura(){
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Cual es su altura (En centimntros)"));
        return altura;
    }

    public int meta(){
        System.out.println("------------------------------------------------");
        String[] meta = {"Bajar de peso" , "Subir de peso", "Salir"};
        for(int i=0; i<meta.length;i++){
            System.out.println((i+1) + ". " + meta[i]);
            System.out.println("------------------------------------------------");
        }return meta.length;
    }

    public int mal(int amountOptions){
        boolean next_step = false;
        int selection = 0;
        do{
            try{
                selection = Integer.parseInt(JOptionPane.showInputDialog("Ingrese una de las opciones: " ));
                if(selection < 0 || selection > amountOptions){
                    System.err.println("DEBE INGRESAR UNA OPCION VALIDA");
                }else{
                    next_step = true;
                }
            }catch(NumberFormatException e){
                System.err.println("INGRESE UN VALOR NUMERICO");
            }
        }while(!next_step);
        return selection;
    }

    public void welcomeMessage(){
        System.out.println("Bienvenidos a nuestra programa de nutricion, en este programa vas a lograr todas tus metas");
    }

    public int rutina(){
        System.out.println("---------------------------------");
        String[] menuBajarDePeso = {"Ver comidas" , "Ver ejercicios", "Regresar al menu"};
        
        for (int i=0; i<menuBajarDePeso.length;i++){
            System.out.println((i+1) + ". " + menuBajarDePeso[i]);
            System.out.println("---------------------------------");

        }return menuBajarDePeso.length;
    }

    public void end_System(){
        System.out.println("Gracias por utilizar nuestro programa, no se rinda hasta lograr todas sus metas");
    }
}
