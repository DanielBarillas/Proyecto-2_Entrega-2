import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
//import java.nio.Buffer;
import java.util.ArrayList;

public class CSV{

    // Atributos <-----------------------------------------------------------------------------      
    private String header;

    void writeCSV(String file , String user, String pass,double altura, double peso, String sexo){//
        try{
            FileWriter fileWriter = new FileWriter(file, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            PrintWriter printWriter = new PrintWriter(bufferedWriter);
            printWriter.println(user + "," + pass+ ","+ altura+ "," + peso + "," + sexo );//

            printWriter.flush();
            printWriter.close();


        }catch(IOException e ){
            System.out.println(e);
        }
    }

    int [] readCSV(String file, int n) throws IOException{
        int[]array = new int[n];

        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        String line = null;
        int count =0;

        while((line = bufferedReader.readLine()) != null){
            String [] parts = line.split(",");
            int total_parts = parts.length;

            for (int i=0; i<total_parts; i++){
                int aux =0;
                if (i%2 !=0){
                    array[count] = Integer.parseInt(parts[i]);
                    count++;
                }
            }
        }return array;
            
        
    }

    public ArrayList<Usuario> readFileContent(String ruta){
        ArrayList<Usuario> dataUsuarios = new ArrayList<Usuario>();
        BufferedReader bf;

        try {
            bf = new BufferedReader(new FileReader(ruta));
            String temp = "";
            String bfRead;

            while((bfRead = bf.readLine()) != null){
                temp = temp + bfRead + "\n";
            }

            // El temp tendrá la información del archivo
            // Ahora vamos a preparar y adaptar la informacion
            String[] lines = temp.split("\n"); // Separar contenido por lineas

            header = lines[0];

            for (int i = 1; i < lines.length; i++) {
                // Separar el contenido de la linea por comas para obtener los datos individualmente
                String[] estudentData = lines[i].split(",");

                String name = estudentData[0];                
                String constra = estudentData[1];
                float altura = Float.parseFloat(estudentData[2]);
                float peso = Float.parseFloat(estudentData[3]);
                String sexo = estudentData[4];

                // data.add(new DataStudent(carne, name, notes)); // Agregar nuevo estudiante con sus respectivos datos
                dataUsuarios.add(new Usuario(name, constra, altura, peso, sexo));
                // System.out.println("Tdoo en orden");
                // for (Usuario user : dataUsuarios) {
                //     System.out.println("-> " + user.getNombres());
                // }
            }
                        
        } catch (Exception e) {
            dataUsuarios = null;
            // System.out.println("Error en leer");
        }

        return dataUsuarios;
    }   
}