import java.util.ArrayList;
import javax.swing.JOptionPane;

public class SesionUsuario extends Usuario{

    Usuario user = new Usuario();
    public static SesionUsuario sUsuario = new SesionUsuario();
    Vista v = new Vista();
    CSV csv = new CSV();
    private static Usuario usuarioLogeado = null;
    private String GlobalName;

    public void Sesion() {
        int whl = 0;
        int OpInicio;
        while (whl != 1) {

            OpInicio = v.MenuIngreso();

            if (OpInicio == 1) {                
                Usuario usuarioDetectado = sUsuario.IniciarSesion(csv.readFileContent("RegistrarUsuarios.csv"));
                if(usuarioDetectado == null){
                    // Esto quiere decir que el usuario es invalido y/o se equivoco de contraseño o usuario
                    System.out.println("-----------------------------------------------------------------------");
                    System.out.println("El login es inválido porque ha ingresado mal su contraseña o username");
                    System.out.println("-----------------------------------------------------------------------\n");
                }
                else{
                    // Llamar al método del menu nuevo
                    usuarioLogeado = usuarioDetectado;
                    setNombreCompleto(usuarioDetectado.getNombreCompleto());
                    whl = 1;
                    System.out.println("------------------------------");
                    System.out.println("El login es válido, ha entrado");
                    System.out.println("------------------------------\n");
                }
            } else {
                String user = JOptionPane.showInputDialog(null, "Cual es tu username");
                GlobalName = user;
                String pass = JOptionPane.showInputDialog(null, "Cual es tu password");
                float altura = Float.parseFloat(JOptionPane.showInputDialog(null, "Cual es tu altura (En CM)"));
                float peso = Float.parseFloat(JOptionPane.showInputDialog(null, "Cual es tu peso(En KG)"));
                String sexo = JOptionPane.showInputDialog(null, "Introduce tu género (H (hombre) / M (mujer)): ");
                csv.writeCSV("RegistrarUsuarios.csv",user,pass,altura,peso,sexo);
                whl = 1;
            }
        }
    }

    public Usuario IniciarSesion(ArrayList<Usuario> usuarios) {     

        String username = v.UNombre();
        GlobalName = username;
        String contrasenia = v.UContraseña();

        for (Usuario usuario : usuarios) { // Vamos a buscar dentro de los usuarios leidos coincidencias
            if(username.equals(usuario.getNombreCompleto()) && contrasenia.equals(usuario.getContrasenia())){
                return usuario;
            }
        }
        return null; // Si no coinciden los datos
    }

    //=====================================================================================================================
    //                                  Obtenemos Usuario en sesión
    //=====================================================================================================================

    public String s_getGlobalNombre(ArrayList<Usuario> usuarios) {  
        String GlobalNombre = "";   
        for (Usuario usuario : usuarios) { // Vamos a buscar dentro de los usuarios leidos coincidencias
            GlobalNombre = usuario.getNombreCompleto();
        }
        return GlobalNombre;
    }

    public String s_getGlobalContraseña(ArrayList<Usuario> usuarios) {  
        String GlobalContraseña = "";   
        for (Usuario usuario : usuarios) { // Vamos a buscar dentro de los usuarios leidos coincidencias
            GlobalContraseña = usuario.getContrasenia();
        }
        return GlobalContraseña;
    }

    public float s_getGlobalPeso(ArrayList<Usuario> usuarios) {  
        float GlobalPeso = 0;   
        for (Usuario usuario : usuarios) { // Vamos a buscar dentro de los usuarios leidos coincidencias
            GlobalPeso = usuario.getPeso();
        }
        return GlobalPeso;
    }

    public float s_getGlobalAltura(ArrayList<Usuario> usuarios) {  
        float GlobalAltura = 0;   
        for (Usuario usuario : usuarios) { // Vamos a buscar dentro de los usuarios leidos coincidencias
            GlobalAltura = usuario.getAltura();
        }
        return GlobalAltura;
    }

    public String s_getGlobalSexo(ArrayList<Usuario> usuarios) {  
        String GlobalSexo = "";   
        for (Usuario usuario : usuarios) { // Vamos a buscar dentro de los usuarios leidos coincidencias
            GlobalSexo = usuario.getSexo();
        }
        return GlobalSexo;
    }

    }
