//import javax.swing.JOptionPane;

public class Proyecto{

    public static Vista view = new Vista();
    public static Dietas dietas = new Dietas();
    public static SesionUsuario sUsuario = new SesionUsuario();
    public static CSV csv = new CSV();
    public static Usuario usuario = new Usuario();
 
    
    public static void main(String[] args) {
        sUsuario.Sesion();
        Start();
    }

    static void Start(){

        //Usuario setUser = new Usuario();
        int opcion =0;
        int selection = 1;

        view.DivisionAsteriscos();
        view.welcomeMessage();
        view.horaYFecha();

        while(opcion != selection){
            opcion = view.meta();
            selection = view.mal(opcion);
            switch(selection){
                case 1:
                    dietas.pesoIdeal();
                    break;
                case 2:
                    //dietas.IncioIMC();
                    dietas.IMC();
                    break;
                case 3:
                    dietas.bajarDePeso();
                    break;
                case 4:
                    dietas.subirDePeso();
                    break;
                case 5:
                    sUsuario.Sesion();
                    break;
                default:
                    opcion = selection; 
                    view.end_System();
                    System.exit(0);
                    break;
                }
            }
        }

}