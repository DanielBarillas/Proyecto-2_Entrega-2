public class Usuario {
    private String nombreCompleto;
    private String contrasenia;
    private float altura;
    private float peso;
    private String sexo;

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Usuario() {
        
    }

    public Usuario(String nombreCompleto, String contrasenia, float altura, float peso, String sexo) {
        this.nombreCompleto = nombreCompleto;
        this.contrasenia = contrasenia;
        this.altura = altura;
        this.peso = peso;
        this.sexo = sexo;
    }

}
