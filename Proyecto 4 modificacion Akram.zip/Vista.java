import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Vista {

    Scanner scan = new Scanner(System.in);

    public int MenuIngreso() {
        int op = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa la opción deseada:\n\n" +
                                                                    "   1. Iniciar Sesión.\n" +
                                                                    "   2. Registrarme.\n\n"));
        return op;
    }

    //APARTADO DE INGRESO DE DATOS DEL USUARIO EN SESIÓN. --------------------------------------------------------------------------------
    public String UNombre() {
        String UNombre = JOptionPane.showInputDialog(null, "Ingrese su nombre de usuario");
        return UNombre;
    }

    public String UContraseña() {
        String UContraseña = JOptionPane.showInputDialog(null, "Ingrese su contraseña");
        return UContraseña;
    }

    public double peso(){

        boolean next_step = false;
        double peso = 0;

        do {

            try {

                peso = Double.parseDouble(JOptionPane.showInputDialog("Cual es su peso (En KG) "));
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }

        } while(!next_step); 

        return peso;

       
    }

    public double altura(){

        boolean next_step = false;
        double altura = 0;

        do {

            try {

                altura = Double.parseDouble(JOptionPane.showInputDialog("Cual es su altura (En centimetros)"));
                next_step = true;

            } catch (NumberFormatException e) {
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
                next_step = false;
            }

        } while(!next_step);

        return altura;
    }

    public int meta(){
        System.out.println("------------------------------------------------");
        String[] meta = {"Ver el peso ideal", "Ver IMC", "Bajar de peso" , "Subir de peso", "Cerrar sesion", "Salir"};
        for(int i=0; i<meta.length;i++){
            System.out.println((i+1) + ". " + meta[i]);
            System.out.println("------------------------------------------------");
        }return meta.length;
    }

    public int mal(int amountOptions){
        boolean next_step = false;
        int selection = 0;
        do{
            try{
                selection = Integer.parseInt(JOptionPane.showInputDialog("Ingrese una de las opciones: " ));
                if(selection < 0 || selection > amountOptions){
                    System.err.println("\nDEBE INGRESAR UNA OPCION VALIDA\n");
                }else{
                    next_step = true;
                }
            }catch(NumberFormatException e){
                System.err.println("\nINGRESE UN VALOR NUMERICO\n");
            }
        }while(!next_step);
        return selection;
    }

    public void welcomeMessage(){
        System.out.println("Bienvenidos a nuestra programa de nutricion, en este programa vas a lograr todas tus metas");
    }

    public int rutina(){
        System.out.println("---------------------------------");
        String[] menuBajarDePeso = {"Ver comidas" , "Ver ejercicios", "Regresar al menu"};
        
        for (int i=0; i<menuBajarDePeso.length;i++){
            System.out.println((i+1) + ". " + menuBajarDePeso[i]);
            System.out.println("---------------------------------");

        }return menuBajarDePeso.length;
    }

    public void end_System(){
        JOptionPane.showMessageDialog(null, "-----Gracias por utilizar nuestro programa, no se rinda hasta lograr todas sus metas-----");
    }

    public void DivisionAsteriscos(){
        System.out.println("************************************************************************************");
    }

    public int selection(int options) {
        boolean next_step = false;
        int selection = 0;
        do{
            try{
                // Opciones disponibles, cantidad
                // opción de entrada, del usuario
                System.out.println("\nIngrese una de las opciones\n");
                selection = scan.nextInt();
                if(selection < 1 || selection> options){
                    System.err.println("\n¡Debe de ingresar una de las opciones dispoibles!\n");
                }else{
                    next_step = true;
                }
            }catch(NumberFormatException e){
                System.err.println("\n¡Debe ingresar un valor numérico!\n");
            }catch(InputMismatchException e){
                System.err.println("\n¡No ingrese palabras, por favor, ingrese un valor númerico!\n");
                scan.nextLine();
            }
        }while(!next_step);
        return selection;
    }

    /** 
     * 
     * 
     * Referencia: https://www.delftstack.com/es/howto/java/how-to-get-the-current-date-time-in-java/
     * @return Fecha y hora actual
     */
    public String[] horaYFecha(){
        DivisionAsteriscos();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");
        System.out.println("\nObteniendo la zona horaria: "+ZonedDateTime.now().getZone());
        System.out.println("\nFecha y hora actual-> "+dtf.format(LocalDateTime.now()) + "\n");
        String formato = dtf.format(LocalDateTime.now());
        String[] horaYFecha = formato.split(" ");		
        return horaYFecha;
		// String hora = horaYFecha[0];
		// String fecha = horaYFecha[1];
    }

    public void default1(){
        System.out.println("Esta opción no es válida, ingrese un número de válido");
    }

}